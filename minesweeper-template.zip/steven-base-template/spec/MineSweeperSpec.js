describe('Minesweeper Kata', function () {

    it('should know is true', function () {

        var result= true;

        expect(result).toBe(true);
    });
});